class Student:
    def __init__(self, name, roll_number, gpa):
        self.name = name
        self.roll_number = roll_number
        self.gpa = gpa

def short_students(student_list):
    # Sort the list of student objects based on GPA in descending order
    sorted_students = sorted(student_list, key=lambda student: student.gpa, reverse=True)
    return sorted_students

# Example usage:
student1 = Student("Ruby", "A001", 3.8)
student2 = Student("divi", "B002", 3.5)
student3 = Student("hema", "C003", 4.0)

students = [student1, student2, student3]

sorted_students = short_students(students)

for student in sorted_students:
    print(f"Name: {student.name}, Roll Number: {student.roll_number}, GPA: {student.gpa}")